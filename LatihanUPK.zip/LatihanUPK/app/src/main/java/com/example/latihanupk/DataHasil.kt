package com.example.latihanupk

 class DataHasil(
     val hasil: String,
     val tinggi: String,
     val alas: String
         )
